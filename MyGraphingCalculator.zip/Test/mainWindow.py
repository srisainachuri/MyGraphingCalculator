'''
All the program comments goes in this multiline comment lines

'''

# Make the code compatible with Python 2.x and 3.x versions
try:
    import Tkinter as tk
except ImportError:
    import tkinter as tk


#import tkinter
#from tkinter import messagebox

import math
import json
import urllib.request
from collections import OrderedDict


# Hold onto a global reference for the root window
root = None
mainWindowTitle=None
mainWindowHeader = None
mainWindowUserInfo =None
exitButtonLabel=None

# Hold onto the Text Entry Box also
mathExpresionEntryBox = None
# text to hold mathExpresion
mathExpresion=None

# text to hold variable
mathExpressionVariable=None
# Hold onto the Text Entry Box also
mathvariableEntryBox = None

# text to hold variable Domain 
mathDomainVariable=None
# Hold onto the Text Entry Box also
mathDomainEntryBox = None

# text to hold Integration Limits 
mathIntegrationLimitsVariable=None
# Hold onto the Text Entry Box also
mathIntegrationLimitsEntryBox = None

# Changeable text that will go inside the Label
myText = None
count = 0 # Click counter

# global variables and defaults for window size etc
h= 700
w= 900
upDomain = 10
downDomain = -10
interval = 0.0001
upRange = 10
downRange = -10 
n = 0
mainX = []
mainY = []
functionContinuityList=[]
mainContinuousX= []
mainContinuousY= []
firstX=[]
firstY = []
secondX = []
secondY = []
lines = []
miN = []
maX = []
POI = []
integral = ""
beginDomain = 0
endDomain = 0
beginRange = 0
endRange = 0

def exitButtonPushed():
    global root
    print('Closing the application root window')
    root.destroy() # Kill the root window!

# Function to transform default standard X coordinate system at the center of the canvas as 0,0
def xConvert (xValue):
    if xValue == 0:
        xPixel =w/2
    elif xValue>0:
        frac = float((xValue)/upDomain)
        xPixel = float(w/2 +(frac*(w/2)))
    else:
        frac = float(xValue/downDomain)
        xPixel = float(w/2 -(frac*(w/2)))
    #print (xPixel)
    return (xPixel)
# Function to transform default standard Y coordinate system at the center of the canvas as 0,0
def yConvert (yValue):
    if yValue ==0:
        yPixel =h/2
    elif yValue>0:
        frac = float((-yValue)/upRange)
        yPixel = float(h/2 +(frac*(h/2)))
    else:
        frac = float(-yValue/downRange)
        yPixel = float(h/2 -(frac*(h/2)))
    return (yPixel)

# Main function to interact with the backend RESTFul webservice/Java program to parse math expression, evaluate the function along
# with first derivate, second deriviate and first integral for the given limits
def getJsonData():
    global mainX,mainY,firstX,firstY,secondX, secondY, integral,mainContinuousX,mainContinuousY,functionContinuityList
    mainX=[]
    mainY=[]
    firstX=[]
    firstY=[]
    secondX=[]
    secondY = []
    mainContinuousX=[]
    mainContinuousY=[]
    # RESTFul webservice url is hard coded with the assumption it is running locally on the port 8080
    urlData = "http://localhost:8080/graphingCalculator/webresources/math" + "?mathExpresion=" +mathExpresion+ "&variable="+mathExpressionVariable+"&domain="+mathDomainVariable+"&intergralLimits="+mathIntegrationLimitsVariable
    webURL = urllib.request.urlopen(urlData)
    data = webURL.read()
    encoding = webURL.info().get_content_charset('utf-8')
    JSON_object = json.loads(data.decode(encoding))
    pointsList = JSON_object["pointsList"]
    firstDerivatePointsList = JSON_object["firstDerivatePointsList"]
    secondDerivatePointsList = JSON_object["secondDerivatePointsList"]
    integral = JSON_object["integration"]
    functionContinuityList=JSON_object["functionContinutityList"];
    print (beginDomain)
    print(endDomain)
    print(functionContinuityList);
    for point in pointsList:
        #print(point)
        if type(point[1])is float:
                    mainX.append(point[0])
                    mainY.append(point[1])
    for point in firstDerivatePointsList:
        #print(point)
                if type(point[1])is float:
                    firstX.append(point[0])
                    firstY.append(point[1])
    for point in secondDerivatePointsList:
                if type(point[1])is float:
                    secondX.append(point[0])
                    secondY.append(point[1])

#Main action to read user input and compute the desired math expression/functions.
def graphButtonPushed():
    global mathExpresion,mathExpresionEntryBox,mathExpressionVariable,mathvariableEntryBox
    global mathDomainVariable,mathDomainEntryBox,mathIntegrationLimitsVariable,mathIntegrationLimitsEntryBox
    global lines,mainX,mainY,firstX,firstY,integral,mainContinuousX,mainContinuousY,functionContinuityList
    miN = []
    maX = []
    POI = []
    txt = mathExpresionEntryBox.get()
    mathExpresion=txt
    print('mathExpresion entered :' + mathExpresion)
    mathExpressionVariable = mathvariableEntryBox.get()
    print('mathExpresionVaiable entered :' + mathExpressionVariable)
    mathDomainVariable = mathDomainEntryBox.get()
    print('mathDomainVariable entered :' + mathDomainVariable)
    mathIntegrationLimitsVariable = mathIntegrationLimitsEntryBox.get()
    print('mathIntegrationLimitsVariable entered :' + mathIntegrationLimitsVariable)

    functionDomain = mathDomainVariable.split(",")
    beginDomain = float(functionDomain[0])
    endDomain = float(functionDomain[1])

    print (beginDomain, endDomain)
    #Create Pop Up window for drawing graphing
    w= tk.Toplevel()
    w.destroy()
    toplevel = tk.Toplevel()
    h= 700
    w= 900
    upDomain = endDomain
    downDomain = beginDomain
    interval = 0.0001
    upRange = 10
    ownRange = -10 
    
    C = tk.Canvas(toplevel, bg = "white", height = h+10, width = w+10)
    for line in lines:
        C.delete(line)
        print('Deleting line with id:',line)
      
    C.pack()
    items=C.find_all()
    #print(len(items))

    #Wipe any widgets on the canvas for fresh canvas for redraw
    C.delete(tk.ALL)
    C.pack()
    lineX = C.create_line(0, h/2, w,h/2,fill='black', width=1)
    lineY= C.create_line(w/2,0, w/2,h,fill='black', width=1)
    lines.append(lineX)
    lines.append(lineY)
    spacing = upDomain/10
    print (spacing, upDomain)
    conserveSpacing = upDomain/10
    while spacing<= upDomain:
        C.create_line(xConvert(spacing), h/2+h/100, xConvert(spacing), h/2-h/100)
        C.create_text(xConvert(spacing),h/2+h/100+10, text=spacing)
        spacing = spacing+conserveSpacing

    spacing = upRange/10
    conserveSpacing = upRange/10
    while spacing<= upRange:
        C.create_line(w/2+w/100, yConvert(spacing), w/2-w/100, yConvert(spacing))
        C.create_text(w/2+w/100-30, yConvert(spacing), text=spacing)
        spacing = spacing+conserveSpacing

    spacing = downDomain/10
    conserveSpacing = downDomain/10
    while spacing>= downDomain:
        C.create_line(xConvert(spacing), h/2+h/100, xConvert(spacing), h/2-h/100)
        C.create_text(xConvert(spacing),h/2+h/100+10, text=spacing)
        spacing = spacing+conserveSpacing

    spacing = downRange/10
    conserveSpacing = downRange/10
    while spacing>= downRange:
        C.create_line(w/2+w/100, yConvert(spacing), w/2-w/100, yConvert(spacing))
        C.create_text(w/2+w/100-30, yConvert(spacing), text=spacing)
        spacing = spacing+conserveSpacing
    
    print (mainY)
    # Get the data from backend java code
    getJsonData()
    count = 0

    # get removable Continuious x coordinate list
    removableXcoordinateList =[]
    pointCount = 0
    while pointCount< len((functionContinuityList[pointCount])[1]):
                if ((functionContinuityList[pointCount])[1])=='NaN':
                #if not type(point[1])is float:                    
                    removableXcoordinateList.append(point[0])
                pointCount = pointCount+1
    if(len(removableXcoordinateList)>0):
        print("Function : ",mathExpresion," removable continuious at following x values :\n",removableXcoordinateList)
        C.create_text(200,110, text="Function : "+mathExpresion+" removable continuious at following x values :\n", fill="green")
        listString=""
        for x in removableXcoordinateList:
            listString = '%.5f' % x+","+listString
        C.create_text(200,130, text=listString, fill="green")

            
    # Graph original function using tkinter Canvas create_line widget.
    count = 0
    print('Count of mainX:',len(mainX))

    #custom math sign function to return if the number is positive or negative number
    sign=lambda x: math.copysign(1,x)
    for x in mainX:
        if count<(len(mainY)-2) :
            # find the mid point of y for x between removable Continuious x coordinate
            
            #clear drawing line at asymptote condition
            if count>1 and (sign(mainY[count])!=sign(mainY[count+1])) and math.fabs((math.fabs(mainY[count+1])-math.fabs(mainY[count])))>1:
                C.create_line(xConvert(mainX[count]), yConvert(mainY[count]), xConvert(mainX[count+1]), yConvert((mainY[count+1])), fill="#fff",joinstyle="round",smooth=1)
            else:
                C.create_line(xConvert(mainX[count]), yConvert(mainY[count]), xConvert(mainX[count+1]), yConvert((mainY[count+1])), fill="green",joinstyle="round",smooth=1)
               
            #C.create_oval(xConvert(mainX[count]) -1, yConvert(mainY[count]) -1, xConvert(mainX[count]) +1, yConvert(mainY[count]) +1, fill="green")
                
        count = count +1
    
    # Graph the first derivate
    print (firstX)
    count = 0
    for x in firstX:
        if count<(len(firstY)-2):
            #clear drawing line at asymptote condition
            if(count>1 and (sign(firstY[count])!=sign(firstY[count+1])) and math.fabs((math.fabs(firstY[count+1])-math.fabs(firstY[count])))>1):
                C.create_line(xConvert(firstX[count]), yConvert(firstY[count]), xConvert(firstX[count+1]), yConvert((firstY[count+1])), fill="#fff",joinstyle="round")
            else:
                C.create_line(xConvert(firstX[count]), yConvert(firstY[count]), xConvert(firstX[count+1]), yConvert((firstY[count+1])), fill="red",joinstyle="round")
            if count>0 and firstY[count]>0 and (firstY[count-1])<0:
                miN.append(count)
                print ("Min", firstX[count])
                print ("coord", mainX[count])
            elif count>0 and firstY[count]<0 and (firstY[count-1])>0:
                maX.append(count)
                print ("Max", firstX[count])
        count = count +1

    # Graph the second derivate
    count = 0
    print("Second Y : ",secondY)
    for x in secondY:
        if count<(len(secondY)-2):
            #clear drawing line at asymptote condition
            if(count>1 and (sign(secondY[count])!=sign(secondY[count+1])) and math.fabs((math.fabs(secondY[count+1])-math.fabs(secondY[count])))>1):
                C.create_line(xConvert(secondX[count]), yConvert(secondY[count]), xConvert(secondX[count+1]), yConvert((secondY[count+1])), fill="#fff",joinstyle="round")
            else:
                C.create_line(xConvert(secondX[count]), yConvert(secondY[count]), xConvert(secondX[count+1]), yConvert((secondY[count+1])), fill="blue",joinstyle="round")
            if count>0 and (((secondY[count])>0 and (secondY[count-1])<0)or ((secondY[count])<0 and (secondY[count-1])>0)):
                POI.append(count)
                print ("POI", secondX[count])
        count = count +1
    C.create_text(100,20, text="Integral Value : "+integral)
    C.create_text(100,35, text="Legend:")
    C.create_text(100,50, text="______ Function", fill="green")
    C.create_text(100,65, text="______ First Derivative", fill="red")
    C.create_text(100,80, text="______ Second Derivative", fill="blue")

    #plotMinMax()
    for c in miN:
        x=xConvert(mainX[c])+55
        y=yConvert(mainY[c])+55
        C.create_line(xConvert(mainX[c]), yConvert(mainY[c]), xConvert(mainX[c])+50, yConvert(mainY[c])+50, arrow=tk.FIRST, fill = 'purple',width=2)
        C.create_text(x,y , text=" min", fill="black")
    for c in maX:
        x=xConvert(mainX[c])+55
        y=yConvert(mainY[c])-55
        C.create_line(xConvert(mainX[c]), yConvert(mainY[c]), xConvert(mainX[c])+50, yConvert(mainY[c])-50, arrow=tk.FIRST, fill = 'orange',width=2)
        C.create_text(x,y , text=" max", fill="black")
    for c in POI:
        x=xConvert(mainX[c])
        y=yConvert(mainY[c])+55
        C.create_line(xConvert(mainX[c]), yConvert(mainY[c]), xConvert(mainX[c]), yConvert(mainY[c])+50, arrow=tk.FIRST, fill = 'turquoise',width=2)
        C.create_text(x,y , text=" POI", fill="black")
    # draw removable Continuious points
   
    
        
    C.pack()
'''   
    #Calculate Integral
    count = 0
    area = 0
    while count<5:
            area = area + interval*0.5*(sin(count)+sin(count+interval))
        
    print (area)
'''           

    
    
#Functions related to main GUI window for user interaction
def addTextLabel(root):
    global myText
    myText = StringVar()
    myText.set("")
    myLabel = Label(root, textvariable=myText)
    myLabel.pack()  
    
def createMathExpresionEntryTextBox(parent):
    global mathExpresionEntryBox
    mathExpresionEntryBox = tk.Entry(parent,width=50)
    mathExpresionEntryBox.pack()    

def createMathVariableEntryTextBox(parent):
    global mathvariableEntryBox
    mathvariableEntryBox = tk.Entry(parent)
    mathvariableEntryBox.pack() 
def createMathDomainEntryBox(parent):
    global mathDomainEntryBox
    mathDomainEntryBox = tk.Entry(parent)
    mathDomainEntryBox.pack()        

# mathIntegrationLimitsEntryBox
def createMathIntegrationLimitsEntryBox(parent):
    global mathIntegrationLimitsEntryBox
    mathIntegrationLimitsEntryBox = tk.Entry(parent)
    mathIntegrationLimitsEntryBox.pack()
    
def main():
    global root
    global mainWindowTitle
    mainWindowTitle='Srisai Nachuri: Graphing tool for the following:'
    global mainWindowHeader 
    mainWindowHeader = 'Graphing tool for math function, its first derivate,second derivate and first integral'
    global mainWindowUserInfo 
    mainWindowUserInfo =    """
    Usage:
    * Graph ANY polynomial rational expression
    * Graph ANY polynomial function
    * Graph logarithmic( ln , log ), trigonometric (sin, cos, tan ), or exponential functions
    * Given any f’(x) accurately show the fundamental theorem of calculus for any two values on the given domain
    """

    global exitButtonLabel
    exitButtonLabel='Exit'
    
    root = tk.Tk() # Create the root (base) window where all widgets go
    root.title(mainWindowTitle)
    # Frames
    headerAndInfoFrame = tk.Frame(root, highlightbackground="green", highlightcolor="green", highlightthickness=2, width=900, height=120, bd= 0,bg="pale turquoise")
    
    
    mainWindowHeader = tk.Label(headerAndInfoFrame, text=mainWindowHeader,font="Times 15 bold",bg='pale turquoise') # Create a label with words
    mainWindowHeader.pack() # Put the label into the window
    userInfo = tk.Label(headerAndInfoFrame, text=mainWindowUserInfo,font="Times 10 bold",bg='pale turquoise')
    #userInfo.place(x=25, y=25, anchor="w")
    userInfo.pack()
    headerAndInfoFrame.pack(side=tk.TOP)
    headerAndInfoFrame.pack_propagate(False)
    #tkinter.Entry(headerAndInfoFrame).pack()
    
    # Frames
    userInputFrame = tk.Frame(root, highlightbackground="blue", highlightcolor="blue", highlightthickness=2, width=450, height=300, bd= 1,bg='khaki')
    
    userInstructions = tk.Label(userInputFrame, text="Please enter the values in the text box and click Graph it button \n",font="Times 10 bold",bg="khaki")
    #createMathExpresionEntryTextBoxLabel.place(relx=0.5, rely=0.5, anchor="w")
    userInstructions.pack()
    
    # createMathExpresionEntryTextBox and label
    createMathExpresionEntryTextBoxLabel = tk.Label(userInputFrame, text="Math Expression",bg="khaki",font="Times 12 bold")
    #createMathExpresionEntryTextBoxLabel.place(relx=0.5, rely=0.5, anchor="w")
    createMathExpresionEntryTextBoxLabel.pack()
    createMathExpresionEntryTextBox(userInputFrame)
    
    # createMathVariableEntryTextBox and label
    createMathVariableEntryTextBoxLabel = tk.Label(userInputFrame, text="Math Expression Variable",bg="khaki",font="Times 12 bold")
    createMathVariableEntryTextBoxLabel.pack()
    #screateMathVariableEntryTextBoxLabel.place(relx=0.5, rely=0.5, anchor="w")
    createMathVariableEntryTextBox(userInputFrame)
    
    
    # createMathDomainEntryBox and label
    createMathDomainEntryBoxLabel = tk.Label(userInputFrame, text="Math Expression Domain (comma delimited whole numbers)",bg="khaki",font="Times 12 bold")
    createMathDomainEntryBoxLabel.pack()
    createMathDomainEntryBox(userInputFrame)
    
    # mathIntegrationLimitsEntryBox and label
    createmathIntegrationLimitsEntryBoxLabel = tk.Label(userInputFrame, text="Enter Integration Limits(comma delimited numbers)",bg="khaki",font="Times 12 bold")
    createmathIntegrationLimitsEntryBoxLabel.pack()
    createMathIntegrationLimitsEntryBox(userInputFrame)
    
    # graph Button
    
    #from tk.ttk import Separator as ttkSeparator
    #ttkSeparator(root,orient='horizontal').pack()
    graphButton = tk.Button(userInputFrame, text='Graph it !!',command=graphButtonPushed,bg="yellow green",font="Times 15 bold")
    graphButton.pack()
    
    userInputFrame.pack(side=tk.LEFT)
    userInputFrame.pack_propagate(False)
    #tkinter.Entry(userInputFrame).pack()
    
    # Frames
    exitFrame = tk.Frame(root, highlightbackground="red", highlightcolor="red", highlightthickness=2, width=450, height=300, bd= 1)
    
    #exit Button
    exitButton = tk.Button(exitFrame, text=exitButtonLabel,command=exitButtonPushed,font="Times 20 bold")
    exitButton.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
    #exitButton.pack()
    exitFrame.pack(side=tk.RIGHT)
    exitFrame.pack_propagate(False)
    
    #exitButton.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
    
    
    root.mainloop() # Start the event loop  
        


main()

