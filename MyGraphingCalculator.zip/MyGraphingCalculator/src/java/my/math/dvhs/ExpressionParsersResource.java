/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.math.dvhs;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.text.DecimalFormat;
import org.json.*;
import org.json.simple.JSONArray;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import javax.ws.rs.core.MultivaluedMap;
import java.math.BigDecimal;

/**
 * REST Web Service
 *
 * @author snachuri
 */
@Path("/math")
public class ExpressionParsersResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of ExpressionParsersResource
     */
    public ExpressionParsersResource() {
    }

    /**
     * Retrieves representation of an instance of
     * my.math.dvhs.ExpressionParsersResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        // throw new UnsupportedOperationException();
        String query = context.getRequestUri().getQuery();

        System.out.println("query :" + query);
        java.util.StringTokenizer queryString = new java.util.StringTokenizer(query, "&");
        Map<String, String> map = new HashMap<String, String>();

        while (queryString.hasMoreElements()) {

            String actualElement = queryString.nextToken();
            StringTokenizer et = new StringTokenizer(actualElement, "=");

            if (et.countTokens() != 2) {
                throw new RuntimeException("Unexpeced format");
            }

            String key = et.nextToken();
            String value = et.nextToken();

            map.put(key, value);
        }
        System.out.println("++++++++++++++++");
        System.out.println(map);
        System.out.println(map.get("mathExpresion"));
        System.out.println(map.get("variable"));
        System.out.println(map.get("domain"));
        System.out.println(map.get("intergralLimits"));
        System.out.println("++++++++++++++++");

        String jsonData = "";

        try {
            //return mathExpressionData;
            //jsonData = this.getJsonData4(map.get("mathExpresion"),map.get("variable"),map.get("range"));
            jsonData = this.getJsonData5(map.get("mathExpresion"), map.get("variable"), map.get("domain"), map.get("intergralLimits"));
        } catch (IOException ex) {
            Logger.getLogger(ExpressionParsersResource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return jsonData;
    }

    /**
     * POST method for creating an instance of ExpressionParserResource
     *
     * @param content representation for the new resource
     * @return an HTTP response with content of the created resource
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response postJson(String content) {
        //TODO
        return Response.created(context.getAbsolutePath()).build();
    }

    /**
     * Sub-resource locator method for {id}
     */
    @Path("{id}")
    public ExpressionParserResource getExpressionParserResource(@PathParam("id") String id) {
        return ExpressionParserResource.getInstance(id);
    }

    public static void main(String args[]) {
        try {
            //http://juliusdavies.ca/json-simple-1.1.1-javadocs/org/json/simple/JSONArray.html
            //creating JSON Array

            //getJsonData2()
            ExpressionParsersResource expr = new ExpressionParsersResource();
            //System.out.println(getJsonData3());
            //String jsonString = expr.getJsonData5("sin(x)","x","-10,10","-2,8");
            // String jsonString = expr.getJsonData5("(x^2-1)/(x-1)", "x", "-10,10", "1,2");
            // DecimalFormat
            String jsonString = expr.getJsonData5("ln(x)", "x", "-10,10", "1,2");
            System.out.println(jsonString);
        } catch (IOException ex) {
            Logger.getLogger(ExpressionParsersResource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static String getJsonData5(String mathExpr, String mathVar, String domain, String intergralLimits) throws IOException {
        String jsonData = "";
        //String mathExpr = "3*x^2";
        // String mathVar = "x";
        String[] functionLimits = domain.split(",");
        System.out.println(new Double(functionLimits[0]));
        System.out.println(new Double(functionLimits[1]));
        String[] integrationLimits = intergralLimits.split(",");
        System.out.println(new Double(integrationLimits[0]));
        System.out.println(new Double(integrationLimits[1]));

        double lowerLimit = new Double(functionLimits[0]);
        double upperLimit = new Double(functionLimits[1]);
        double interval = 0.1;
        double derivateDelta = 0.00001;
        double integrationDelta = 0.00001;
        double integralLowerLimit = new Double(integrationLimits[0]);
        double integralUpperLimit = new Double(integrationLimits[1]);
        double firsIntegral = 0;
        // build the data structure for the json
        Coordinate coordinate = new Coordinate(mathExpr, mathVar);

        coordinate.setFunctionLimitsList(functionLimits);
        List<List<Double>> pointsList = new ArrayList<List<Double>>();
        List<List<Double>> firstDerivatePointsList = new ArrayList<List<Double>>();
        List<List<Double>> secondDerivatePointsList = new ArrayList<List<Double>>();
        List<List<Double>> functionContinuityList = new ArrayList<List<Double>>();

        TextParser m = new TextParser(mathExpr);
        double xVal = lowerLimit;
        m.addVariable(mathVar, xVal);
        double yVal = m.getValue();

        // calculate the continuity at whole number between the domain values
        for (int i = (int) lowerLimit; i <= (int) upperLimit; i++) {
            // Format the decimal value to restrict to pre-defined number decimal digits
            DecimalFormat df = new DecimalFormat("#.######");// set it to 6 decimal places
            df.setRoundingMode(java.math.RoundingMode.CEILING);
            List<Double> point = new ArrayList<Double>();
            m.addVariable(mathVar, i);
            double y = m.getValue();
            point.add(new Double(i));
            point.add(new Double(y));// math expression evaluation
            functionContinuityList.add(point);
        }
        // derivatives and function
        while (xVal <= upperLimit) {
            // Format the decimal value to restrict to pre-defined number decimal digits
            DecimalFormat df = new DecimalFormat("#.######");// set it to 6 decimal places
            df.setRoundingMode(java.math.RoundingMode.CEILING);
            List<Double> point = new ArrayList<Double>();
            point.add(new Double(df.format(xVal)));
            if (Double.isNaN(yVal)) {
                System.out.println(yVal);
                point.add(new Double(yVal));
            } else {
                point.add(new Double(df.format(yVal)));// math expression evaluation
            }
            pointsList.add(point);

            // derivate
            List<Double> firstDerivatePoint = new ArrayList<Double>();
            m.addVariable(mathVar, xVal + derivateDelta);
            double fxPlusDeltaX = m.getValue();
            double slopeOneOne = calculateSlope(fxPlusDeltaX, yVal, derivateDelta);

            firstDerivatePoint.add(new Double(df.format(xVal)));
            if (Double.isNaN(slopeOneOne)) {
                firstDerivatePoint.add(new Double(slopeOneOne));
            } else {
                firstDerivatePoint.add(new Double(df.format(slopeOneOne)));
            }
            firstDerivatePointsList.add(firstDerivatePoint);

            //Second Derivative 
            df = new DecimalFormat("#.##");
            double incrementPoint = fxPlusDeltaX;
            m.addVariable(mathVar, xVal + 2 * derivateDelta);
            fxPlusDeltaX = m.getValue();
            List<Double> secondDerivativePoint = new ArrayList<Double>();
            double slopeOneTwo = calculateSlope(fxPlusDeltaX, incrementPoint, derivateDelta);
            double slopeTwo = calculateSlope(slopeOneTwo, slopeOneOne, derivateDelta);

            secondDerivativePoint.add(new Double(df.format(xVal)));
            if (Double.isNaN(yVal)) {
                secondDerivativePoint.add(new Double(slopeTwo));
            } else {
                secondDerivativePoint.add(new Double(df.format(slopeTwo)));
            }
            secondDerivatePointsList.add(secondDerivativePoint);

            xVal = xVal + interval;
            m.addVariable(mathVar, xVal);
            yVal = m.getValue();
            //System.out.println(xVal + "," + yVal);

        }

        // calculate first Intgeral
        xVal = integralLowerLimit;
        // https://www.intmath.com/integration/5-trapezoidal-rule.php
        // area = deltaX((y0)/2+y1+y2 +y3+...+yn-1+(yn)/2)
        double Intsum = 0;
        m.addVariable(mathVar, xVal);
        double yValFirst = yVal = m.getValue();
        double yValLast = 0;
        while (xVal <= integralUpperLimit) {
            // add the increments
            xVal = xVal + integrationDelta;
            m.addVariable(mathVar, xVal);
            yVal = m.getValue();
            if (xVal >= integralUpperLimit) {
                yValLast = yVal;
            } else {
                // adding y1...yn-1
                Intsum = Intsum + yVal;
            }
        }
        // finally compute the area 
        double area = integrationDelta * (yValFirst / 2 + yValLast / 2 + Intsum);

        ObjectMapper mapper = new ObjectMapper();
        coordinate.setpointsList(pointsList);
        coordinate.setFirstDerivatePointsList(firstDerivatePointsList);
        coordinate.setSecondDerivatePointsList(secondDerivatePointsList);
        coordinate.setfunctionContinutityList(functionContinuityList);
        DecimalFormat decimalFormat = new DecimalFormat("#");
        System.out.println("area in float :" + area);
        coordinate.setintegration(new Double(area).toString());

        String json = mapper.writeValueAsString(coordinate);
        return json;
    }

    private static Double calculateSlope(double fxPlusDeltaX, double fx, double deltaX) {
        Double slope = new Double(0);
        // https://www.mathsisfun.com/calculus/derivatives-introduction.html
        //The slope formula is:	 (f(x+Δx) − f(x))/Δx 
        slope = (fxPlusDeltaX - fx) / deltaX;
        return slope;
    }
    /*private static Double c(double fxPlusDeltaX,double fx,double deltaX){
        Double area = new Double(0);
        //https://www.mathsisfun.com/calculus/integration-definite.html
	//The area formula is:	 ((f(x+Δx) + f(x))/2 )*Δx 
        System.out.println("fxPlusDeltaX: " +fxPlusDeltaX);
        System.out.println("fx: " +fx);
        System.out.println("deltaX: " +deltaX);
        double sumOfParalleSides =fxPlusDeltaX +fx;
        sumOfParalleSides = sumOfParalleSides/2;
        System.out.println("sumOfParalleSides: " +sumOfParalleSides);
        System.out.println("sumOfParalleSides*deltaX: " +sumOfParalleSides*deltaX);
        area = ((fxPlusDeltaX + fx)/2 )*deltaX;
        System.out.println("area: " +area);
        DecimalFormat decimalFormat = new DecimalFormat("#");
        System.out.println("area in float :" + decimalFormat.format(area));
        return area;
}*/
}
