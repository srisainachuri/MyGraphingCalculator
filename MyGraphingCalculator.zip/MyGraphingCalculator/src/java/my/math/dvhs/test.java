/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.math.dvhs;

/**
 *
 * @author snachuri
 */
public class test {
    public static void main(String[] args){
     System.out.println(Math.PI);
     System.out.println(Math.PI/2);
     System.out.println(Math.tan(0));
     System.out.println(Math.tan(Math.PI/2));
     System.out.println(Math.tan(1.5707963267948966));
     double min = new Double(-10.9991);
     double max = new Double(9.987111);
     for(int i=(int)min;i<=(int)max;i++){
     System.out.println(i);
     }
     
    }
    
}
