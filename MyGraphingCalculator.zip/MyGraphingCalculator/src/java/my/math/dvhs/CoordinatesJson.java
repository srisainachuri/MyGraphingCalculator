/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.math.dvhs;

/**
 *
 * @author snachuri
 */
import java.io.IOException;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

public class CoordinatesJson {
    
    public static void main(String[] args) throws JsonGenerationException, JsonMappingException, IOException {
        ObjectMapper mapper = new ObjectMapper();
       
        Coordinate coordinate = new Coordinate("x*3+12", "x");
        //Person person = new Person(1, "Arvind", address);
        
        List<List<Double>> pointsList = new ArrayList<List<Double>>();
        
        
        for (int i = 1; i < 10; i++) {
            List<Double> point = new ArrayList<Double>();
            point.add(new Double(i));
            point.add(new Double(i*2+10));// math expression evaluation
            pointsList.add(point);
        }
            
        
        coordinate.setpointsList(pointsList);
        
        String json = mapper.writeValueAsString(coordinate);
        
        System.out.println(json);
    }
    
}
