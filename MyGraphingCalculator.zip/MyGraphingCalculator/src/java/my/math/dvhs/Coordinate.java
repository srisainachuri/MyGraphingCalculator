/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.math.dvhs;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author snachuri
 */
public class Coordinate {

    private String mathExpression;
    private String exprVariable;
    private List<List<Double>> pointsList  = new ArrayList<List<Double>>();
    private List<List<Double>> firstDerivatePointsList = new ArrayList<List<Double>>();
    private List<List<Double>> secondDerivatePointsList = new ArrayList<List<Double>>();

    private double firstIntegral;
    private String integration;
    private String[] functionLimits ;
    private List<List<Double>> functionContinuityList = new ArrayList<List<Double>>();
   
    public Coordinate(String mathExpression, String exprVariable) {
        this.mathExpression = mathExpression;
        this.exprVariable = exprVariable;

    }
    public Coordinate(String mathExpression, String exprVariable,String integralValue) {
        this.mathExpression = mathExpression;
        this.exprVariable = exprVariable;
       // this.firstIntegral = new Double(integralValue);
        this.integration = integralValue;

    }

    public String getmathExpression() {
        return mathExpression;
    }

    public void setmathExpression(String mathExpression) {
        this.mathExpression = mathExpression;
    }

    public String getexprVariable() {
        return exprVariable;
    }

    public void setexprVariable(String exprVariable) {
        this.exprVariable = exprVariable;
    }
     public  List<List<Double>> getpointsList() {
        return pointsList;
    }

    public void setpointsList( List<List<Double>> list) {
        this.pointsList = list;
    }
    
    public  List<List<Double>> getFirstDerivatePointsList() {
        return this.firstDerivatePointsList;
    }

    public void setFirstDerivatePointsList( List<List<Double>> list) {
        this.firstDerivatePointsList = list;
    }
    
    public  List<List<Double>> getSecondDerivatePointsList() {
        return this.secondDerivatePointsList;
    }

    public void setSecondDerivatePointsList( List<List<Double>> list) {
        this.secondDerivatePointsList = list;
    }
    
    public  String[] getFunctionLimitsList() {
        return this.functionLimits;
    }

    public void setFunctionLimitsList( String[] list) {
        this.functionLimits = list;
    }
   // firstIntegral
    public void setfirstIntegral(Double integralValue){
           System.out.println(integralValue);
          this.firstIntegral = integralValue;
    }
    public Double getfirstIntegral(Double integralValue){
        System.out.println("In get for firstIntegral" +integralValue);
        return this.firstIntegral;
    }
    
    public String getintegration() {
        return integration;
    }

    public void setintegration(String exprVariable) {
        this.integration = exprVariable;
    }
    // continuity points
    public void setfunctionContinutityList(List<List<Double>> list){
           
          this.functionContinuityList = list;
    }
    public List<List<Double>> getfunctionContinutityList(){
        //System.out.println("In get for firstIntegral" +integralValue);
        return this.functionContinuityList;
    }
}
